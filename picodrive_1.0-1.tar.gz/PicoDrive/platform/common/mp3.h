
#ifdef __GP2X__
void mp3_update_local(int *buffer, int length, int stereo);
void mp3_start_local(void);
#endif

