# Defaults for picodrive initscript
# sourced by /etc/init.d/picodrive
# installed at /etc/default/picodrive by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
