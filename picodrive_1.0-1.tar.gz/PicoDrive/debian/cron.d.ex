#
# Regular cron jobs for the picodrive package
#
0 4	* * *	root	picodrive_maintenance
