?package(picodrive):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="picodrive" command="/usr/bin/picodrive"
